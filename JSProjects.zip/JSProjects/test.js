console.log("Page is ready");
let index = "";
// let formData;
var fullname = document.getElementById("fullname").value;
var emp_code = document.getElementById("emp_code").value;
var salary = document.getElementById("salary").value;
var city = document.getElementById("city").value;
displayData();


function onFormSubmit(){

    if(fullname == ''){
        document.getElementById('fullname_msg').innerHTML = "Please enter for name!";
    }

    if(emp_code == ''){
        document.getElementById('emp_code_msg').innerHTML = "Please enter a Emp_ID!";
    }
    if(salary == ''){
        document.getElementById('salary_msg').innerHTML = "Please enter your salary";
    }
    if(city == ''){
        document.getElementById('city_msg').innerHTML = "Please the city name!";
    }
 
    let formData = JSON.parse(localStorage.getItem('formData')) || [];
        formData.push({
            fullname: document.getElementById("fullname").value,
            emp_code: document.getElementById("emp_code").value,
            salary: document.getElementById("salary").value,
            city: document.getElementById("city").value
        });

    localStorage.setItem('formData', JSON.stringify(formData));
    displayData();
    // fullname = '';
    // emp_code = '';
    // salary = '';
    // city = '';
    // e.preventDefault();
}

function displayData(){
    let arr = JSON.parse(localStorage.getItem('formData'));
    // console.log(arr);
    if(arr != null){
        let html = '';
        let s_no = 1;
        for(let k in arr){
            // console.log(arr[k]['emp_code']);
            html =html+`<tr><td>${s_no}</td><td>${arr[k]['fullname']}</td><td>${arr[k]['emp_code']}</td><td>${arr[k]['salary']}</td><td>${arr[k]['city']}</td><td style="background-color:;"><button style:"color:red;"><a href="javascript:void(0)" onclick="editData(${k});">Edit</a></button></td><td><button><a href="javascript:void(0)" onclick="deleteData(${k})">Delete</a></button></td></tr>`;
            s_no++;
        }
        document.getElementById('table_body').innerHTML = html;
    }
}
let submit = document.getElementById('submit');
let update = document.getElementById('update');

function editData(rid){
    index = rid;
    // console.log(index);
    let arr = JSON.parse(localStorage.getItem('formData'));
    for(let k in arr){
        if( index == k){
        // fullname = document.getElementById(arr[k]['fullname']);
        document.getElementById('fullname').value = arr[index]['fullname'];
        document.getElementById('emp_code').value = arr[index]['emp_code'];
        document.getElementById('salary').value = arr[index]['salary'];
        document.getElementById('city').value = arr[index]['city'];
        // arr = JSON.stringify('formData');
        }
    }
    submit.style.display = "none";
    update.style.display = "block";
    displayData();
}

function update(){
    
}
// let update = document.getElementById('update');
// console.log(update);

function deleteData(rid){
    submit.style.display = "block";
    update.style.display = "none";
    index = rid;
    let dlt_itm = JSON.parse(localStorage.getItem('formData'));
    console.log(dlt_itm);
    dlt_itm.splice(index,1);
    localStorage.setItem('formData',JSON.stringify(dlt_itm));
    displayData();
}

// const obj = JSON.parse('{"name":"John", "age":30, "city":"New York"}');
// const person = {
//     name: "Obaseki Nosa",
//     location: "Lagos",
// }

// window.localStorage.setItem('user', JSON.stringify(person));