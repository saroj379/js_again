var selectedRow = null;
function onFormSubmit(){
    var formData = readFormData();
    // if(selectedRow === null){
    //     insertNewRecord(formData);
    // }
    // else{
    //         updateRecord(FormData);
    // }
   insertNewRecord(formData);
}

function readFormData(){
    var formData={};
    formData["emp_id"] = document.getElementById("emp_id").value;
    formData["name"] = document.getElementById("name").value;
    formData["dob"] = document.getElementById("dob").value;
    formData["qualification"] = document.getElementById("qualification").value;
    formData["gender"] = document.getElementById("gender").value;
    formData["hobbies"] = document.getElementById("hobbies").value;
    return formData;

}

function insertNewRecord(data){
   var table = document.getElementById("root").getElementsByTagName('tbody')[0];
   var newRow = table.insertRow(table.length);
   cell1 = newRow.insertCell(0);
   cell1.innerHTML = data.emp_id;
   cell2 = newRow.insertCell(1);
   cell2.innerHTML = data.name;
   cell3 = newRow.insertCell(2);
   cell3.innerHTML = data.dob;
   cell4 = newRow.insertCell(3);
   cell4.innerHTML = data.qualification;
   cell5 = newRow.insertCell(4);
   cell5.innerHTML = data.gender;
   cell6 = newRow.insertCell(5);
   cell6.innerHTML = data.hobbies;
   cell7 = newRow.insertCell(6);
   cell7.innerHTML = `<a><Edit/a>
                    <a>Delete</a>`
}

// function resetForm(){
//     document.getElementById('emp_id').value = "";
//     document.getElementById('name').value = "";
//     document.getElementById('dob').value = "";
//     document.getElementById('qualification').value = "";
//     document.getElementById('gender').value = "";
//     document.getElementById('hobbies').value = "";
//     selectedRow = null;
// }

// function onEdit(td){
//     selectedRow = td.parentElement.parentElement;
//     document.getElementById('emp_id').value = selectedRow.cells[0].innerHTML;
//     document.getElementById('name').value = selectedRow.cells[1].innerHTML;
//     document.getElementById('dob').value = selectedRow.cells[2].innerHTML;
//     document.getElementById('qualification').value = selectedRow.cells[3].innerHTML;
//     document.getElementById('gender').value = selectedRow.cells[4].innerHTML;
//     document.getElementById('hobbies').value = selectedRow.cells[5].innerHTML;
// }

// function updateRecord(formData){
//     selectedRow.cells[0].innerHTML = formData.emp_id;
//     selectedRow.cells[1].innerHTML = formData.name;
//     selectedRow.cells[2].innerHTML = formData.dob;
//     selectedRow.cells[3].innerHTML = formData.qualification;
//     selectedRow.cells[4].innerHTML = formData.gender;
//     selectedRow.cells[5].innerHTML = formData.hobbies;
// }

// function onDelete(td){
//     if(confirm("Are you sure to delete this record?")){
//         row = td.parentElement.parentElement;
//         document.getElementById('employeeList').delete(row.rowIndex);
//         resetForm();
//     }
// }



// localStorage.setItem('thor');
// localStorage.setItem('emp_id', '1');
// // var myEmpId = localStorage.getItem()
// console.log(localstorage.getItem('emp_id'));