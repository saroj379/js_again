console.log("Hey, You can use now!");
SelectData();
let id="no";
     
// SelectData();
function onformSubmit(){
    document.getElementById('msg').innerHTML="";
    let name = document.getElementById('name').value;
    if(name == ''){
        document.getElementById('msg').innerHTML="Please enter a data..";
    }
    else{
        if(id="no"){
            let arr = JSON.parse(localStorage.getItem('crud'));
            console.log(arr);
            if(arr == null){
                let data = [name];
                // console.log(name);
                localStorage.setItem('crud',JSON.stringify(data));
            }else{
                arr.push(name);
                localStorage.setItem('crud',JSON.stringify(arr));
            }
            document.getElementById('msg').innerHTML = "Data Insert Seccessfully!"
        }else{
            let arr = JSON.parse(localStorage.getItem('crud'));
            arr[id] =name;
            setCrudData(arr);
            document.getElementById('msg').innerHTML = "Data updated!";
        }
        document.getElementById('name').value =      "";
        SelectData();
    }
}

function SelectData(){
    let arr = JSON.stringify(localStorage.getItem('crud'));
    if(arr != null){
        let html = '';
        let s_no = 1;
        for(let k in arr){
            html = `<tr><td>${s_no}</td><td>${arr[k]}</td><td><a href="javascript:void(0)" onclick="editData(${k})">Edit</a></td><td><a href="javascript:void(0)" onclick="deleteData(${k})">Delete</a></td></tr>`;
            s_no++;
        }
        document.getElementById('root').innerHTML = html;
    }
}

// function editData(rid){
//     id = rid;
//     let arr = JSON.parse(localStorage.getItem('crud'));
//     document.getElementById('name').value = arr[rid];
// }

// function deleteData(rid){
//     let arr = JSON.parse(localStorage.getItem('crud'));
//     arr.splice(rid,1);
//     localStorage.setItem('crud',JSON.stringify(arr));
//     SelectData();
// }

// function getCrudData(){
//     let arr = JSON.parse(localStorage.getItem('crud'));
//     return arr;
// }

// function setCrudData(arr){
//     localStorage.setItem('crud',JSON.stringify(arr));
// }


